# cd your_path/MERL/zeroshot
python test_zeroshot.py